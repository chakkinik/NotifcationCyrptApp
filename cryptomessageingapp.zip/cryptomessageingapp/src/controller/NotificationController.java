package controller;

import modal.NotifcationResponse;
import modal.NotificationRequest;

public class NotificationController {




    public NotifcationResponse send(NotificationRequest notificationRequest){
        // validationRequest
        // call the notfication service




        return new NotifcationResponse();

    }

}
