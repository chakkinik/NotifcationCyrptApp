public class Main {
    public static void main(String[] args) {

        /*
        Create a notification.
         Line items may include current price of BTC, market trade volume, intra day high price, market cap
Send a notification to an email
List sent notifications (sent, outstanding, failed etc.)
Delete a notification


    Modal.

    consumer id.

    // regsiter api will generate some of id.

    // you pass the conumer id(app_id) to validate ..



    // we have to store the




    event:

    channel :->

    NotifcationObj.



         */
        System.out.println("Hello world!");
    }
}