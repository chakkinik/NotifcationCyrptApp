package Dao;

import modal.Consumer;
import modal.Event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class InmemoryDB {


    public  static  List<Consumer> consumerDB = new ArrayList<>();

    public  static  Map<UUID,Consumer> consumerCache = new HashMap<>();

    public static  List<Event> events = new ArrayList<>();

    public static List<Event> getEvents() {
        return events;
    }

    private Map<String, Object> meta_data = new HashMap<>();

    public static void loadData(){
        // load dummy data
    }

    public static Consumer getConsumer(UUID cid) throws Exception {

        if (!consumerCache.containsKey(cid)) {
            throw new Exception("Consumer is not presnt");
        }
       return consumerCache.get(cid);
    }

    public static void save(Event event){
        events.add(event);
    }






}
