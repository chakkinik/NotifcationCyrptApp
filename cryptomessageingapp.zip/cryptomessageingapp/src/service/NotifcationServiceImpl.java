package service;

import Dao.InmemoryDB;
import modal.Channel;
import modal.Consumer;
import modal.Event;
import modal.EventService;
import modal.NotificationRequest;
import modal.Status;

import java.util.List;
import java.util.UUID;

public class NotifcationServiceImpl implements  NotificationService {


    /// can wrap the runtime exception

    @Override
    public void create(UUID consumerId) throws Exception {

      Consumer consumer = InmemoryDB.getConsumer(consumerId);

        Channel channel = consumer.getChannel();
        List<String> emailIds = consumer.getEmailIds();

        // Have to insert the metadata .. into template;

        Event event = new Event(UUID.randomUUID(),consumerId, Status.PASSED);

        EventService.create(event);



        for(String eachEmail: emailIds){
            BroadCast.cast(consumer.getTemplate());
        }

        //async the event to pass..


    }

    @Override
    public void retry() {

    }

    @Override
    public void print() {

    }

    @Override
    public void delete() {

    }
}
