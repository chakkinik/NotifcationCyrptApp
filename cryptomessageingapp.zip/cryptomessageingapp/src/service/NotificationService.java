package service;

import modal.NotificationRequest;

import java.util.UUID;

public interface NotificationService {




    public void create(UUID cid) throws Exception;


    public void retry();

    public void print();

    public void delete();



}
