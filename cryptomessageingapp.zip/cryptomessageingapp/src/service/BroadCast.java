package service;

public class BroadCast {

    public static void cast(String message){
        System.out.println(message);
    }
}
