package modal;

import java.util.List;
import java.util.UUID;

public class Consumer {

    private UUID uuid;

    private List<String> emailIds;

    private Channel channel;

    public Consumer(UUID uuid, List<String> emailIds, Channel channel, String template) {
        this.uuid = uuid;
        this.emailIds = emailIds;
        this.channel = channel;
        this.template = template;
    }

    public UUID getUuid() {
        return uuid;
    }

    public List<String> getEmailIds() {
        return emailIds;
    }

    public Channel getChannel() {
        return channel;
    }

    public String getTemplate() {
        return template;
    }

    private String template;

}
