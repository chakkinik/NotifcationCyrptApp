package modal;

import java.util.List;

public class ErrorResponse {

    private String statusCode;

    private List<Error> errors;


}


