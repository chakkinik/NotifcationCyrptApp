package modal;

import java.util.UUID;

public class NotificationRequest {
    public UUID getConsumerId() {
        return consumerId;
    }

    public UUID consumerId;

    public NotificationRequest(UUID consumerId) {
        this.consumerId = consumerId;
    }
}
