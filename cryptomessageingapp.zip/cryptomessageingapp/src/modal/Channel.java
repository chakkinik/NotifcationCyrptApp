package modal;

public enum Channel {

    EMAIL, SMS
}
