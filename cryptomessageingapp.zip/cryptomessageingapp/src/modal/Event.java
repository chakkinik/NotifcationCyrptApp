package modal;

import java.util.UUID;




public class Event {

    private UUID eventId;
    private UUID cid;

    public void setEventId(UUID eventId) {
        this.eventId = eventId;
    }

    public void setCid(UUID cid) {
        this.cid = cid;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public UUID getEventId() {
        return eventId;
    }

    public UUID getCid() {
        return cid;
    }

    public Status getStatus() {
        return status;
    }

    private Status status;

    public Event(UUID eventId, UUID cid, Status status) {
        this.eventId = eventId;
        this.cid = cid;
        this.status = status;
    }
}
