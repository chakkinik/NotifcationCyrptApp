package modal;

import Dao.InmemoryDB;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class EventService {

    // manage the event

    public static  void create(Event event){
        InmemoryDB.save(event);
    }



    public static List<Event> getEventListConsumer(UUID cid){
        List<Event> events = InmemoryDB.getEvents();
        //filter out ..
        List<Event> eventToBeSent = new ArrayList<>();

        for(Event event:events){
            if(event.getCid().equals(cid)){
                eventToBeSent.add(event);
            }
        }

        return eventToBeSent;

    }

    public static   void delete(UUID eid){
        //delete the particular event from DB;
    }


}
