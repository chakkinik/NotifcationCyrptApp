package modal;

public class NotifcationResponse {

    private String statusCode;

    private String successMessage;

    private ErrorResponse errorResponse;


}
