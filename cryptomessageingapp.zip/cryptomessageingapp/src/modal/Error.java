package modal;

public class Error {
    private String statusCode;
    private String message;
}
