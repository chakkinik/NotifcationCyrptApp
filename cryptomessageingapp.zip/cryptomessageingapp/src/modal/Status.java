package modal;

public enum Status {

    PASSED, FAIL, BLOCKED
}
